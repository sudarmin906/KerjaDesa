# KerjaDesa Android V27

Android WebView wrapper for the KerjaDesa web application.

- Package: `com.kerjadesa.app`
- Target SDK: 36
- Version code: 27
- Version name: 1.1.0
- Debug APK is signed with the Android debug key and intended for device testing.
- Release AAB produced by the workflow is unsigned and is not yet ready for Google Play until signed with the owner's upload/release key.
