# KerjaDesa Android V26

Wrapper Android resmi untuk KerjaDesa PWA.

- Package: `com.kerjadesa.app`
- Target SDK: Android 16 / API 36
- URL aplikasi: https://sudarmin906.github.io/KerjaDesa/
- Fitur file upload didukung melalui WebView.

## Build tanpa komputer lokal
1. Upload folder proyek ini ke repository GitHub baru/branch Android.
2. Buka tab **Actions**.
3. Pilih workflow **Build KerjaDesa Android**.
4. Klik **Run workflow**.
5. Setelah selesai, buka hasil workflow dan download artifact `KerjaDesa-Android-build`.
6. `app-debug.apk` dapat dipasang untuk uji coba.
7. `app-release.aab` perlu ditandatangani untuk rilis Google Play.

Google Play mewajibkan aplikasi baru/update menargetkan Android 16 (API 36) atau lebih tinggi mulai 31 Agustus 2026.
