KerjaDesa Android V28 FINAL

Project: KerjaDesa
Package: com.kerjadesa.app
Version code: 28
Target/compile SDK: 36

This package intentionally does not depend on a Gradle Wrapper. The GitHub Actions workflow installs Gradle 8.13 with gradle/actions/setup-gradle and installs Android SDK 36 with android-actions/setup-android.

The included WORKFLOW_V28_FINAL.yml is the workflow to use as .github/workflows/android.yml in the GitHub repository.
