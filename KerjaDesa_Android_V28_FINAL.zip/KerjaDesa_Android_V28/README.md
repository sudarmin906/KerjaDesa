# KerjaDesa Android V28

Android WebView wrapper for the live KerjaDesa PWA.

- Package: com.kerjadesa.app
- Version code: 28
- Version name: 1.2.0
- Target/compile SDK: 36
- Minimum SDK: 23
- Start URL: https://sudarmin906.github.io/KerjaDesa/
